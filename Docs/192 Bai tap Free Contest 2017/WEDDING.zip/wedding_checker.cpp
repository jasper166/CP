using namespace std;
#include <bits/stdc++.h>
#define pb push_back
#define fto(i, l, r) for(int i = l; i <= r; ++i)
#define sz(a) (int)a.size()

void cms_assert(bool Condition) {
	if (Condition) return;
	puts("0.0");
	fputs("Wrong answer", stderr);
	exit(0);
}

void verdict(double score, string message) {
    printf("%.2f\n", score);
    fputs(message.c_str(), stderr);
    exit(0);
}

void add(vector<int> &v, char s[]) {
    if (strcmp(s, "Sit") == 0) v.pb(0);
    else if (strcmp(s, "Stand") == 0) v.pb(1);
    else if (strcmp(s, "Unsure") == 0) v.pb(2);
    else if (strcmp(s, "Ignored") == 0) v.pb(3);
    else v.pb(4);
}

int main (int argc, char ** argv) {
    char s[10]; s[0] = 0;
    vector<int> jury, contestant;

    freopen(argv[2], "r", stdin);
    while (scanf("%s", s) != EOF)
        add(jury, s);

    freopen(argv[3], "r", stdin);
    while (scanf("%s", s) != EOF)
        add(contestant, s);

    if (sz(jury) != sz(contestant))
        verdict(0, "Output presentation is incorrect.");

    int n = sz(jury), correct = 0, wrong = 0, ignored = 0;
    fto(i, 0, n-1) {
        int ans = jury[i], out = contestant[i];
        if (out == 4)
            verdict(0, "Output presentation is incorrect.");
        if (out == 3)
            ignored++;
        else if (ans == out)
            correct++;
        else
            wrong++;
    }

    double score = 1.0*max(0, correct*7-wrong*4)/(n*7);
    printf("%.2f\n", score);
    fprintf(stderr, "Received: %d, Correct: %d, Wrong: %d, Ignored: %d\n", n, correct, wrong, ignored);

    return 0;
}

