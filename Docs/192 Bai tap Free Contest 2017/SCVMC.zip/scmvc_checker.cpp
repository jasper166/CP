using namespace std;
#include <bits/stdc++.h>
typedef long long ll;
#define pb push_back
#define fto(i, l, r) for(int i = l; i <= r; ++i)
#define fdto(i, r, l) for(int i = r; i >= l; --i)
#define sz(a) (int)a.size()
#define maxN 200005
#define maxK 25

void verdict(double score, string message) {
    printf("%.2f\n", score);
    fputs(message.c_str(), stderr);
    exit(0);
}

void read(string &s) {
    char tmp[20]; scanf("%s", tmp);
    s.assign(tmp);
}

int T, n, k, m, avail[maxN], b[maxK][maxN], d[maxN];
vector<int> g[maxN];

void DFS(int u, int p) {
    for(int v: g[u]) {
        if (v == p) continue;
        b[0][v] = u;
        d[v] = d[u]+1;
        DFS(v, u);
    }
}

int LCA(int u, int v) {
    if (d[u] < d[v]) swap(u, v);
    int t = d[u]-d[v];
    fto(i, 0, m) {
        if ((t>>i)&1) u = b[i][u];
    }

    fdto(i, m, 0) {
        if (b[i][u] != b[i][v]) {
            u = b[i][u];
            v = b[i][v];
        }
    }

    if (u == v) return u;
    fto(i, 0, m) {
        if (b[i][u] == b[i][v]) return b[i][u];
    }
}

int main (int argc, char ** argv) {
    freopen(argv[1], "r", stdin);
    scanf("%d", &T);
    scanf("%d%d", &n, &k);
    fto(i, 1, 2*k) {
        int u; scanf("%d", &u);
        ++avail[u];
    }
    fto(i, 1, n-1) {
        int u, v; scanf("%d%d", &u, &v);
        g[u].pb(v); g[v].pb(u);
    }

    freopen(argv[2], "r", stdin);
    ll ansJury; scanf("%lld", &ansJury);

    freopen(argv[3], "r", stdin);
    ll ansContestant; scanf("%lld", &ansContestant);

    if (ansContestant != ansJury)
        verdict(0, "Suboptimal length sum.");

    string decision; read(decision);
    if (decision == "YES") {
        DFS(1, -1);
        m = log2(n);
        fto(i, 1, m) {
            fto(u, 1, n) b[i][u] = b[i-1][b[i-1][u]];
        }

        ll sum = 0;
        fto(i, 1, k) {
            int u, v; scanf("%d%d", &u, &v);
            if (u < 1 || u > n || v < 1 || v > n || avail[u] == 0 || avail[v] == 0) {
                verdict(0.3, "Optimal length sum, invalid matching.");
            }
            --avail[u]; --avail[v];
            sum += d[u]+d[v]-2*d[LCA(u, v)];
        }

        if (sum == ansJury)
            verdict(1.0, "Optimal length sum, optimal matching.");
        else
            verdict(0.3, "Optimal length sum, suboptimal matching.");
    } else if (decision == "NO") {
        verdict(0.55, "Optimal length sum, contestant refused to give a matching.");
    } else
        verdict(0.3, "Optimal length sum, received a string different from YES and NO.");

    return 0;
}

