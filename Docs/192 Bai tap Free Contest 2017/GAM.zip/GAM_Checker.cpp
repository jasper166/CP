using namespace std;
#include <bits/stdc++.h>

void cms_assert(bool Condition) {
	if (Condition) return;
	puts("0.0");
	fputs("Wrong answer", stderr);
	exit(0);
}

int main (int argc, char ** argv) {
    freopen(argv[2], "r", stdin);
    double answer; scanf("%lf", &answer);

    freopen(argv[3], "r", stdin);
    double output; scanf("%lf", &output);

    bool ac = (abs(answer-output)/max(1.0d, answer) <= 1e-6);
    cms_assert(ac);

	puts("1.0");
	fputs("Correct", stderr);

    return 0;
}
