1: Test loai 0
2,3: Test loai 1
3-9: Test loai 2
10: Test loai 3

Test max 1_6