#include<bits/stdc++.h>

using namespace std;

int main(){
    srand(8888);
    freopen("script.txt","w",stdout);
    for(int i = 1 ; i <= 9; i++)   printf("mkdir s1_%d\n",i);
    printf("random_generator.exe 0 %d >s1_1/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 1 %d >s1_2/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 1 %d >s1_3/bracket.inp\n",rand()%11111 + 1);
    for(int i = 4 ; i <= 9 ; i++)
        printf("random_generator.exe 2 %d >s1_%d/bracket.inp\n",rand()%11111 + 1,i);
    for(int i = 1 ; i <= 10 ; i++)  printf("subtask1.exe <s1_%d/bracket.inp >s1_%d/bracket.out\n",i,i);
}
