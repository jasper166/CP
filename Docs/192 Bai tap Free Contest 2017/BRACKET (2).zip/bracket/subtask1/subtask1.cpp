#include<bits/stdc++.h>
#define N 22
using namespace std;

int p[N] , n , m, ans;
int bracket_sequence[N], /*1 mean open, 0 mean close*/ _p[N];
stack < int > st;

int test_sequence(){
    memset(_p , -1 , sizeof _p);
    while(!st.empty())  st.pop();
    for(int i = 1 ; i <= n ; i++){
        if(bracket_sequence[i] == 1) st.push(i);
        else{
            if(st.empty())  return 0;
            _p[i] = st.top();
            _p[st.top()] = i;
            st.pop();
        }
    }
    if(!st.empty()) return 0;
    for(int i = 1 ; i <= n ; i++)   if(p[i] != -1 && _p[i] != p[i]) return 0;
    return 1;

}

int main(){
    memset(p , -1 , sizeof p);
    scanf("%d %d",&n,&m);
    for(int i = 1 ; i <= m ; i++){
        int x , y;
        scanf("%d %d",&x,&y);
        if(x == y){
            printf("0");
            return 0;
        }
        if(p[x] != -1 && p[x] != y){
            printf("0");
            return 0;
        }
        if(p[y] != -1 && p[y] != x){
            printf("0");
            return 0;
        }
        p[x] = y;
        p[y] = x;
    }
    for(int mask = 0 ; mask < (1<<n) ; mask++){
        for(int i = 0 ; i < n ; i++)
            if(mask&1<<i) bracket_sequence[i + 1] = 0;
            else bracket_sequence[i + 1] = 1;
        ans += test_sequence();
    }
    printf("%d",ans);
}



