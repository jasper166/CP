#include<bits/stdc++.h>
#define N 205

using namespace std;

int mod = 1e9 + 7;
int f[N][N] , p[N] , n , m;

int cal(int l,int r){
    if(f[l][r] != -1)   return f[l][r];
    if(l > r)   return f[l][r] = 1;
    f[l][r] = 0;
    if(p[l] != -1){
        if(p[l] > r || p[l] < l)    return f[l][r] = 0;
        return f[l][r] = 1ll*cal(l + 1 , p[l] - 1)*cal(p[l] + 1 , r)%mod;
    }
    for(int i = l + 1 ; i <= r ; i++) if(p[i] == -1) f[l][r] = (f[l][r] + 1ll*cal(l + 1 , i - 1)*cal(i + 1 , r))%mod;
    return f[l][r];
}


int main(){
    memset(p , -1 , sizeof p);
    memset(f , -1 , sizeof f);
    scanf("%d %d",&n,&m);
    for(int i = 1 ; i <= m ; i++){
        int x , y;
        scanf("%d %d",&x,&y);
        if(x == y){
            printf("0");
            return 0;
        }
        if(p[x] != -1 && p[x] != y){
            printf("0");
            return 0;
        }
        if(p[y] != -1 && p[y] != x){
            printf("0");
            return 0;
        }
        p[x] = y;
        p[y] = x;
    }
    printf("%d",cal(1 , n));
}

