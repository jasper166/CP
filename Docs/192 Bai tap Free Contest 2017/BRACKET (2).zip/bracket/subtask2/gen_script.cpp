#include<bits/stdc++.h>

using namespace std;

int main(){
    srand(7777);
    freopen("script.txt","w",stdout);
    for(int i = 1 ; i <= 15; i++)   printf("mkdir s2_%d\n",i);
    printf("random_generator.exe 0 %d >s2_1/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 1 %d >s2_2/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 1 %d >s2_3/bracket.inp\n",rand()%11111 + 1);
    for(int i = 4 ; i <= 13 ; i++)
        printf("random_generator.exe 2 %d >s2_%d/bracket.inp\n",rand()%11111 + 1,i);
    printf("random_generator.exe 3 %d >s2_14/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 3 %d >s2_15/bracket.inp\n",rand()%11111 + 1);
    for(int i = 1 ; i <= 15 ; i++)  printf("subtask2.exe <s2_%d/bracket.inp >s2_%d/bracket.out\n",i,i);
}
