1: Test loai 0
2: Test loai 1
4-13: Test loai 2
14,15: Test loai 3
3: Test max n