// To run: ./validator < path/to/BRACKET.INP

#include "bits/stdc++.h"
#include "testlib.h"
using namespace std;

const int MAXN = 1e6;

int main(int argc, char* argv[]) {
	registerValidation(argc, argv);
    int n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    int m = inf.readInt(0, MAXN, "m");
    inf.readEoln();

    cout << "n = " << n << ", m = " << m << endl;

    for (int i = 0; i < m; i++) {
        int x = inf.readInt(1, n, "xi");
        inf.readSpace();
        inf.readInt(x, n, "yi");
        inf.readEoln();
    }

    inf.readEof();
}
