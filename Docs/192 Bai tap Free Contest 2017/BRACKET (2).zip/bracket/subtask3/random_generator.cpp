#include<bits/stdc++.h>
#define N 1000000
using namespace std;

int randInt(int l,int r){
    return l + rand()%(r - l + 1);
}

int n , m , p[N] , cnt_open;
stack < int > st;
bool is_appear[N];
vector < int > req , a , b;

void add_open(int x){
    cnt_open++;
    st.push(x);
}

void add_close(int x){
    p[x] = st.top();
    p[st.top()] = x;
    st.pop();
}

void gen_code2(int t){
    n = randInt(2000, 2500)*2; m = randInt(1, n/3);
    for(int i = 1 ; i <= n ; i++){
        if(cnt_open == n / 2)   add_close(i);
        else if(st.empty())     add_open(i);
        else{
            int x = randInt(1 , 2);
            if(x == 1)  add_open(i);
            else add_close(i);
        }
    }
    for(int i = 1 ; i <= m ; i++){
        int x = randInt(1 , n);
        if(x > p[x])  x = p[x];
        if(!is_appear[x])    req.push_back(x);
        is_appear[x] = true;
    }
    int L = (t == 0 ? 1 : 100);
    printf("%d %d\n",n,L*req.size());
    for(int l = 1 ; l <= L ; l++)
        for(int i = 0 ; i < req.size() ; i++)   printf("%d %d\n",req[i],p[req[i]]);
}

void gen_code0(){
    n = randInt(2000 , 2500)*2; m = randInt(10 , 20);
    printf("%d %d\n",n,m);
    for(int i = 1 ; i <= m ; i++){
        int x = randInt(1 , n);
        int y = randInt(1 , n);
        if(x > y)   swap(x , y);
        printf("%d %d\n",x,y);
    }
}

void gen_code1(){
    n = randInt(2000 , 2500)*2; m = randInt(1 , n/3);
    for(int i = 1 ; i <= m ; i++){
        int x = randInt(1 , n);
        int y = randInt(1 , n);
        if(x == y)  continue;
        if(is_appear[x] || is_appear[y])    continue;
        if(x > y)   swap(x , y);
        a.push_back(x); b.push_back(y);
        is_appear[x] = true;
        is_appear[y] = true;
    }
    printf("%d %d\n",n,a.size());
    for(int i = 0 ; i < a.size() ; i++) printf("%d %d\n",a[i],b[i]);
}


int seed, type;

int main(int argc, char * argv []){
    type = atoi(argv[1]);
    seed = atoi(argv[2]);
    srand(seed);
    memset(p , -1 , sizeof p);
    if(type == 0)   gen_code0();
    else if(type == 1)  gen_code1();
    else if (type == 2) gen_code2(0);
    else gen_code2(1);
}
