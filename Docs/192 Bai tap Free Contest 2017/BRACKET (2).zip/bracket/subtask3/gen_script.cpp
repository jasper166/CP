#include<bits/stdc++.h>

using namespace std;

int main(){
    srand(6666);
    freopen("script.txt","w",stdout);
    for(int i = 1 ; i <= 15; i++)   printf("mkdir s3_%d\n",i);
    printf("random_generator.exe 0 %d >s3_1/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 1 %d >s3_2/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 1 %d >s3_3/bracket.inp\n",rand()%11111 + 1);
    for(int i = 4 ; i <= 13 ; i++)
        printf("random_generator.exe 2 %d >s3_%d/bracket.inp\n",rand()%11111 + 1,i);
    printf("random_generator.exe 3 %d >s3_14/bracket.inp\n",rand()%11111 + 1);
    printf("random_generator.exe 3 %d >s3_15/bracket.inp\n",rand()%11111 + 1);
    for(int i = 1 ; i <= 15 ; i++)  printf("subtask4.exe <s3_%d/bracket.inp >s3_%d/bracket.out\n",i,i);
}
