#include<bits/stdc++.h>
#define N 2000000
#define fi first
#define se second
using namespace std;

typedef pair < int , int > ii;
int fact[2*N + 5] , catalan[2*N + 5] , mod = 1e9 + 7;
int p[N] , n , m , ans = 1;
stack < ii > st;
vector < ii > event;

int inverse(int x){
    int ret = 1, mul = x, k = mod - 2;
    while(k > 0){
        if(k%2) ret = 1ll*ret*mul%mod;
        mul = 1ll*mul*mul%mod;
        k /= 2;

    }
    return ret;
}

void prepare(){
    fact[0] = 1;
    for(int i = 1 ; i <= N ; i++) fact[i] = 1ll*fact[i - 1]*i%mod;
    for(int i = 0 ; i <= N ; i++) catalan[i] = 1ll*fact[2*i]*inverse(fact[i])%mod*inverse(fact[i + 1])%mod;
}

int main(){
    prepare();
    memset(p , -1 , sizeof p);
    scanf("%d %d",&n,&m);
    for(int i = 1 ; i <= m ; i++){
        int x , y;
        scanf("%d %d",&x,&y);
        if(x == y){
            printf("%d",0);
            return 0;
        }
        if(p[y] != -1 && p[y] != x){
            printf("%d",0);
            return 0;
        }
        if(p[x] != -1 && p[x] != y){
            printf("%d",0);
            return 0;
        }
        p[y] = x;
        p[x] = y;
    }
    p[0] = n + 1; p[n + 1] = 0;
    for(int i = 0 ; i <= n + 1 ; i++)
        if(p[i] != -1){
            if(p[i] > i)    event.push_back(ii(i , 0));
            else event.push_back(ii(i , 1));
        }
    sort(event.begin() , event.end());
    for(int i = 0 ; i < event.size() ; i++){
        if(event[i].se == 0)    st.push(ii(event[i].fi , 0));
        else{
            int L = event[i].fi - st.top().fi - 1 - st.top().se;
            int X = event[i].fi - st.top().fi + 1;
            if(p[event[i].fi] != st.top().fi){
                printf("0");
                return 0;
            }
            if(L >= 0){
                if(L%2){
                    printf("0");
                    return 0;
                }
                ans = 1ll*ans*catalan[L / 2]%mod;
            }
            st.pop();
            if(!st.empty()) st.top().se += X;
        }
    }
    printf("%d",ans);
}


