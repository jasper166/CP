#include<bits/stdc++.h>

using namespace std;

int main(){
    srand(2222);
    freopen("script.txt","w",stdout);
    for(int i = 1 ; i <= 10; i++)   printf("mkdir s4_%d\n",i);
    for(int i = 1 ; i <= 10 ; i++)
        printf("random_generator.exe 2 %d >s4_%d/bracket.inp\n",rand()%11111 + 1,i);
    for(int i = 1 ; i <= 10 ; i++)  printf("subtask4.exe <s4_%d/bracket.inp >s4_%d/bracket.out\n",i,i);
}
