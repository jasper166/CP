using namespace std;
#include <bits/stdc++.h>
typedef long long ll;
#define pb push_back
#define fto(i, l, r) for(int i = l; i <= r; ++i)
#define fdto(i, r, l) for(int i = r; i >= l; --i)
#define sz(a) (int)a.size()
#define maxN 500005

void verdict(double score, string message) {
    printf("%.2f\n", score);
    fputs(message.c_str(), stderr);
    exit(0);
}

void read(string &s) {
    char tmp[20]; scanf("%s", tmp);
    s.assign(tmp);
}

int n, m, eu[maxN], ev[maxN];
ll sumIn[maxN], sumOut[maxN];

int main (int argc, char ** argv) {
    freopen(argv[1], "r", stdin);
    scanf("%d%d", &n, &m);
    fto(i, 1, m) scanf("%d%d", &eu[i], &ev[i]);

    freopen(argv[2], "r", stdin);
    string ansJury; read(ansJury);

    freopen(argv[3], "r", stdin);
    string ansContestant; read(ansContestant);

    if (ansContestant != ansJury)
        verdict(0, "Incorrect answer.");

    if (ansJury == "NO")
        verdict(1, "Correct.");

    fto(i, 1, m) {
        int w; scanf("%d", &w);
        if (w < 1 || w > 1000000000)
            verdict(0, "Invalid edge weight.");
        sumIn[ev[i]] += w; sumOut[eu[i]] += w;
    }

    fto(u, 1, n) {
        if (sumIn[u] != sumOut[u])
            verdict(0, "Incorrect assignment.");
    }

    verdict(1, "Correct.");

    return 0;
}

