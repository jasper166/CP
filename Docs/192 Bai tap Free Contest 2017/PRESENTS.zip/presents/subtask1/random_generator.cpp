#include<bits/stdc++.h>

using namespace std;
vector < int > a, b;

int seed, type;

int randInt(int l,int r){
    return l + rand()%(r - l + 1);
}


int main(int argc, char *argv[]){
    seed = atoi(argv[1]); type = atoi(argv[2]);
    srand(seed);
    int n = (type == 1 ? 15 : randInt(10,15) );
    for(int i = 1 ; i <= n ; i++){
        a.push_back(rand()%15 + 1);
        if(type != 2)	b.push_back(rand()%15 + 1);
    	   else b.push_back(a.back()); 
    }
    sort(a.begin() , a.end());
    sort(b.begin() , b.end());
    printf("%d\n",n);
    printf("%d", a[0]); for(int i = 1 ; i < a.size() ; i++) printf(" %d",a[i]);
    printf("\n");
    printf("%d",b[0]); for(int i = 1 ; i < b.size() ; i++) printf(" %d",b[i]);
    printf("\n");
}

