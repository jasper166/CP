#include<bits/stdc++.h>

using namespace std;

int main(){
    freopen("script.txt","w",stdout);
    srand(3333);
    for(int i = 1 ; i <= 24 ; i++)  printf("mkdir s1_%d\n",i);
	    for(int i = 1 ; i <= 4  ; i++)  printf("random_generator.exe %d %d >s1_%d/presents.inp\n",rand()%11111,2,i);
    for(int i = 5 ; i <= 24 ; i++)  printf("random_generator.exe %d %d >s1_%d/presents.inp\n",rand()%11111,(i > 20),i);
    for(int i = 1 ; i <= 24 ; i++)  printf("bruteforce.exe <s1_%d/presents.inp >s1_%d/presents.out\n",i,i);
}
