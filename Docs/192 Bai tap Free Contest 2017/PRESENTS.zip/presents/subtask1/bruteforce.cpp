#include<bits/stdc++.h>
#define N 20

using namespace std;
int n , a[N] , b[N] , c[N];
vector < int > X, Y;
bool found_ans;

void back(int k,int sX,int sY){
    if(found_ans)   return ;
    if(k == n){
        if(sX > 0 && sY < 0){
            found_ans = true;
            for(int i = 1 ; i <= n ; i++){
                if(c[i] == 1)   X.push_back(i);
                if(c[i] == 2)   Y.push_back(i);
            }
            return;
        }
    }
    else{
        k++;
        c[k] = 0; back(k , sX , sY);
        if(found_ans)   return ;
        c[k] = 1; back(k , sX + a[k] , sY + b[k]);
        if(found_ans)   return ;
        c[k] = 2; back(k , sX - a[k] , sY - b[k]);
        if(found_ans)   return ;
    }
}

int main(){
    scanf("%d",&n);
    for(int i = 1 ; i <= n ; i++)   scanf("%d",&a[i]);
    for(int i = 1 ; i <= n ; i++)   scanf("%d",&b[i]);
    back(0 , 0 , 0);
    printf("%s\n",(found_ans) ? "YES" : "NO");
    if(found_ans){
        printf("%d",X.size());
        for(int i = 0 ; i < X.size() ; i++) printf(" %d",X[i]);
        printf("\n%d",Y.size());
        for(int i = 0 ; i < Y.size() ; i++) printf(" %d",Y[i]);
    }
}
