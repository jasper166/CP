#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
typedef pair < int , int > ii;
vector < ii > all;
vector < int > a, b;

int seed, type;

int randInt(int l,int r){
    return l + rand()%(r - l + 1);
}


int main(int argc, char *argv[]){
    seed = atoi(argv[1]); type = atoi(argv[2]);
    srand(seed);
    int n = (type == 1 ? 200 : randInt(150,200));
    if(type == 3){
        n = randInt(130 , 190);
        all.push_back(ii(15 , 12)); all.push_back(ii(6 , 1)); all.push_back(ii(5 , 1)); all.push_back(ii(15 , 13));
        sort(all.begin() , all.end());
        for(int i = 0 ; i < n ; i++) all.push_back(ii(200 , 200));
        random_shuffle(all.begin() , all.end());
        printf("%d\n",all.size());
        printf("%d", all[0].fi); for(int i = 1 ; i < all.size() ; i++) printf(" %d",all[i].fi);
        printf("\n");
        printf("%d", all[0].se); for(int i = 1 ; i < all.size() ; i++) printf(" %d",all[i].se);
        printf("\n");
        return 0;
    }
    for(int i = 1 ; i <= n ; i++){
        a.push_back(rand()%200 + 1);
        if(type != 2) b.push_back(rand()%200 + 1);
    	   else b.push_back(a.back());
    }
    sort(a.begin() , a.end());
    sort(b.begin() , b.end());
    printf("%d\n",n);
    printf("%d", a[0]); for(int i = 1 ; i < a.size() ; i++) printf(" %d",a[i]);
    printf("\n");
    printf("%d",b[0]); for(int i = 1 ; i < b.size() ; i++) printf(" %d",b[i]);
    printf("\n");
}

