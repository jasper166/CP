#include<bits/stdc++.h>

using namespace std;

int main(){
    freopen("script.txt","w",stdout);
    srand(6666);
    for(int i = 1 ; i <= 48 ; i++)  printf("mkdir s3_%d\n",i);
    for(int i = 1 ; i <= 5  ; i++)  printf("random_generator.exe %d %d >s3_%d/presents.inp\n",rand()%11111,2,i);
    for(int i = 6 ; i <= 35 ; i++)  printf("random_generator.exe %d %d >s3_%d/presents.inp\n",rand()%11111,3,i);
    for(int i = 36 ; i <= 48 ; i++)  printf("random_generator.exe %d %d >s3_%d/presents.inp\n",rand()%11111,1,i);
    for(int i = 1 ; i <= 48 ; i++)  printf("sol.exe <s3_%d/presents.inp >s3_%d/presents.out\n",i,i);
}
