#include<bits/stdc++.h>

using namespace std;

int main(){
    freopen("script.txt","w",stdout);
    srand(4444);
    for(int i = 1 ; i <= 48 ; i++)  printf("mkdir s2_%d\n",i);
    for(int i = 1 ; i <= 5 ; i++)	printf("random_generator.exe %d %d >s2_%d/presents.inp\n",rand()%11111,2,i);
	for(int i = 6 ; i <= 48 ; i++)  printf("random_generator.exe %d %d >s2_%d/presents.inp\n",rand()%11111,(i > 40),i);
    for(int i = 1 ; i <= 48 ; i++)  printf("sol.exe <s2_%d/presents.inp >s2_%d/presents.out\n",i,i);
}
