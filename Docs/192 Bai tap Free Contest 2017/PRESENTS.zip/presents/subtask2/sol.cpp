#include<bits/stdc++.h>

using namespace std;
#define OFFSET 40000
#define N 200
int f[N + 11][2*OFFSET + 11] , trace[N + 11][2*OFFSET + 11], n , a[N + 11] , b[N + 11] , sa;
vector < int > X , Y;

int main(){
    scanf("%d",&n);
    for(int i = 1 ; i <= n ; i++)   scanf("%d",&a[i]);
    for(int i = 1 ; i <= n ; i++)   scanf("%d",&b[i]);
    sa = accumulate(a + 1 , a + 1 + n , 0);
    for(int i = 0 ; i <= n ; i++)
        for(int j = -sa ; j <= sa ; j++)    f[i][j + OFFSET] = 1e9;
    f[0][0 + OFFSET] = 0;
    for(int i = 0 ; i < n ; i++)
        for(int j = -sa ; j <= sa ; j++)
            if(f[i][j + OFFSET] != 1e9){
                if(f[i + 1][j + OFFSET] > f[i][j + OFFSET]){
                    f[i + 1][j + OFFSET] = f[i][j + OFFSET];
                    trace[i + 1][j + OFFSET] = 0;
                }
                if(f[i + 1][j + OFFSET + a[i + 1]] > f[i][j + OFFSET] + b[i + 1]){
                    f[i + 1][j + OFFSET + a[i + 1]] = f[i][j + OFFSET] + b[i + 1];
                    trace[i + 1][j + OFFSET + a[i + 1]] = 1;
                }
                if(f[i + 1][j + OFFSET - a[i + 1]] > f[i][j + OFFSET] - b[i + 1]){
                    f[i + 1][j + OFFSET - a[i + 1]] = f[i][j + OFFSET] - b[i + 1];
                    trace[i + 1][j + OFFSET - a[i + 1]] = 2;
                }
            }
    int cur = -1;
    for(int i = 1 ; i <= sa ; i++)
        if(f[n][i + OFFSET] < 0){
            cur = i;
            break;
        }
    if(cur == -1){
        printf("NO");
        return 0;
    }
    for(int i = n ; i >= 1 ; i--){
        if(trace[i][cur + OFFSET] == 1){
            X.push_back(i);
            cur -= a[i];
        }
        else if(trace[i][cur + OFFSET] == 2){
            Y.push_back(i);
            cur += a[i];
        }
    }
    printf("YES\n");
    printf("%d",X.size());
    for(int i = 0 ; i < X.size() ; i++) printf(" %d",X[i]);
    printf("\n%d",Y.size());
    for(int i = 0 ; i < Y.size() ; i++) printf(" %d",Y[i]);
}
