// To run: ./validator < path/to/BRACKET.INP

#include "bits/stdc++.h"
#include "testlib.h"
using namespace std;

int main(int argc, char* argv[]) {
	registerValidation(argc, argv);
    int n = inf.readInt(1, 200, "n");
    inf.readEoln();
    cout << "n = " << n << endl;

    for (int turn = 0; turn < 2; turn++) {
        for (int i = 0; i < n; i++) {
            if (i > 0) inf.readSpace();
            inf.readInt(1, 200, "ai");
        }

        inf.readEoln();
    }
    inf.readEof();
}
