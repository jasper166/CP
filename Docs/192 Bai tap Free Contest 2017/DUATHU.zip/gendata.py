import random
N=100
K=25
print(N, K)
for i in range(N):
    print(-500+i*10, random.randrange(2, 30))