#include <bits/stdc++.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <algorithm>

#define MAX_N 200100
using namespace std;

#define ll long long
#define ull unsigned long long
#define ii pair<int,int>
#define iii pair<ii, int>

#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define ep emplace_back
#define sz(a) (int) a.size()
#define cl(a) a.clear()

#define vi vector<int>
#define vii vector<ii>

#define LOWBIT(x) ( (x) & -(x) )

#define FOR(x,a,b) for (int x=a;x<=b;x++)
#define FOD(x,a,b) for (int x=a;x>=b;x--)
#define REP(x,a,b) for (int x=a;x<b;x++)
#define RED(x,a,b) for (int x=a;x>b;x--)

const int MAX = 1e5 + 10;
const int MAXN = 1e4 + 10;
const int MOD = 1e9 + 7;
const int inf = 1e9;
const double pi = acos(-1.0);
const double eps = 1e-6;

int dx[] = {0 , -1 , 0 , 1};
int dy[] = {1 , 0 , -1 , 0};

void cms_assert(bool condition)
{
    if (condition) return;

    puts("0.0");
    fputs("Wrong answer" , stderr);
    exit(0);
}

int n , k , a[MAX_N] , nt , pos[MAX_N];
string s;

int main(int argc , char ** argv)
{
	ios::sync_with_stdio(false);
    cin.tie(0);

    //freopen("input.txt", "r" , stdin);

    if (argc == 4) freopen(argv[1] , "r" , stdin);

    cin >> n >> k;

    FOR(i , 1 , n) cin >> a[i] , a[i] %= k;

    if (argc == 4) freopen(argv[3] , "r" , stdin);

    cin >> s;

    if (s == "YES")
    {
        cin >> nt;

        FOR(i , 1 , nt) cin >> pos[i];
    }

    if (k < n) cms_assert(s == "YES");

    if (s == "YES")
    {
        int sum = 0;

        FOR(i , 1 , nt) (sum += a[pos[i]]) %= k;

        sum %= k;

        if (!sum)
        {
            puts("1.0");
            fputs("Correct" , stderr);
        }
        else
        {
            puts("0.0");
            fputs("Wrong answer" , stderr);
        }
    }
    else
    {
        FOR(i , 1 , n) (a[i] += a[i - 1]) %= k;

        FOR(i , 1 , n)
            REP(j , 0 , i)
            {
                int tmp = a[i] - a[j];

                if (!(tmp % k))
                {
                    puts("0.0");
                    fputs("Wrong answer" , stderr);
                    exit(0);
                }
            }

        puts("1.0");
        fputs("Correct" , stderr);
    }

	return 0;
}
