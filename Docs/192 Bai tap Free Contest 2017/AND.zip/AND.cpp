#include <bits/stdc++.h>

using namespace std;

int n, q;
int a[100005];
int g[31][31];
int cnt[31];
int zeroes;
bool visited[31];

int myvector[31], s;
void add(int num, int sign) {
    if (num == 0) {
        zeroes += sign;
        return;
    }
    for (int i = 0; i < 30; ++i) if (num >> i & 1) myvector[s++] = i;
    for (int i = 0; i < s; ++i) cnt[myvector[i]] += sign;
    for (int i = 0; i < s; ++i) for (int j = 0; j < s; ++j) g[myvector[i]][myvector[j]] += sign;
    s = 0;
}

int main(void) {
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    cin >> n;
    for (int i = 1; i <= n; ++i) {
        int x;
        cin >> x;
        add(x, 1);
        a[i] = x;
    }
    cin >> q;
    while (q--) {
        char type; cin >> type;
        if (type == '?') {
            for (int i = 0; i < 30; ++i) visited[i] = 0;
            int ans = zeroes;
            for (int i = 0; i < 30; ++i) if (cnt[i] > 0 && !visited[i]) {
                ++ans;
                visited[i] = 1;
                myvector[s++] = i;
                while (s) {
                    int u = myvector[--s];
                    for (int v = 0; v < 30; ++v) if (g[u][v] && !visited[v]) {
                        visited[v] = 1;
                        myvector[s++] = v;
                    }
                }
            }
            cout << ans << '\n';
        }
        else {
            int x, y; cin >> x >> y;
            add(a[x], -1);
            a[x] = y;
            add(a[x], 1);
        }
    }
}
