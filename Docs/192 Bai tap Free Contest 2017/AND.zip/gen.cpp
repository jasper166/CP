/*
TODO List:
For each update query:
+   Assign A_i = 0
+   Stop with 1/P probability
+   List the current connected components
+   Match some of them randomly
*/

#include <bits/stdc++.h>

using namespace std;

string to_string(int x, int trunc) {
    string ret;
    for (int i = 0; i < trunc; ++i) {
        ret += char(x % 10 + '0');
        x /= 10;
    }
    reverse(ret.begin(), ret.end());
    return ret;
}
int getbit(int n, int b) { return n >> b & 1; }

namespace solution {
int a[100005];
int g[31][31];
int cnt[31];
int zeroes;
int component_id[31], cur;
int component_size[31];

int myvector[31], s;
void add(int num, int sign) {
    if (num == 0) {
        zeroes += sign;
        return;
    }
    for (int i = 0; i < 30; ++i) if (num >> i & 1) myvector[s++] = i;
    for (int i = 0; i < s; ++i) cnt[myvector[i]] += sign;
    for (int i = 0; i < s; ++i) for (int j = 0; j < s; ++j) g[myvector[i]][myvector[j]] += sign;
    s = 0;
}
void clear(int pos) {
    if (a[pos] == 0) return;
    add(a[pos], -1);
    a[pos] = 0;
}
void assign(int pos, int val) {
    assert(a[pos] == 0);
    if (val == 0) return;
    a[pos] = val;
    add(a[pos], 1);
}
void reset(void) {
    for (int i = 0; i < 30; ++i) cnt[i] = 0;
    for (int i = 0; i < 30; ++i) for (int j = 0; j < 30; ++j) g[i][j] = 0;
    s = zeroes = 0;
}

void answer(void) {
    for (int i = 0; i < 30; ++i) component_id[i] = component_size[i] = 0;
    cur = 0;
    for (int i = 0; i < 30; ++i) if (!component_id[i]) {
        ++cur;
        component_id[i] = cur;
        myvector[s++] = i;
        while (s) {
            int u = myvector[--s];
            ++component_size[cur];
            for (int v = 0; v < 30; ++v) if (g[u][v] && !component_id[v]) {
                component_id[v] = cur;
                myvector[s++] = v;
            }
        }
    }
}
}

namespace test_generator {
#define SMALL_N         0
#define NONZERO         1
#define DEFAULT         2

const int INF = 1e9 + 1;
int P; //1/P = probability to assign A[i] = 0
int group[31], cur;
priority_queue <pair <int, int> > positions;
bool inq[100005];
int zeroed;

int random_int(int lbound = 0, int ubound = INF) { //in range [lbound, ubound)
    long long ret = ((rand() << 16LL) + rand()) % (ubound - lbound) + lbound;
    return ret;
}
void random_partition(void) {
    int b = random_int(2, 10), a = random_int(1, b);
    for (int i = 0; i < 31; ++i) group[i] = 0;
    cur = 1;
    for (int i = 0; i < 30; ++i) {
        int gr, rd = random_int(0, b);
        if (cur == 1 || rd < a) gr = cur;
        else  gr = random_int(1, cur);
        group[gr] |= (1 << i);
        cur = max(cur, gr + 1);
    }
}
int get_value(int nonzero, int allowed_groups) {
    if (!nonzero) {
        int rd = random_int(0, P);
        if (rd < 1) return zeroed = 1, 0;
    }
    solution::answer();
    int ncomponents = solution::cur;
    int to_connect = random_int(0, 1 << ncomponents);
    int ret = 0;
    for (int i = 0; i < 30; ++i) {
        int id = solution::component_id[i];
        if (!getbit(to_connect, id - 1)) continue;
        int rd = random_int(0, solution::component_size[id] * 2);
        if (rd < 1) ret |= (1 << i);
    }
    if (allowed_groups) {
        int ngroup = 0;
        for (int i = 1; i < cur; ++i) if (getbit(allowed_groups, i)) ngroup |= group[i];
        ret &= ngroup;
    }
    if (ret == 0) ret = (1 << random_int(0, 30));
    while (ret >= INF) ret -= ret & -ret;
    return ret;
}
void run(int subtask_no, int type, int maximal) {
    zeroed = 0;
    solution::reset();
    random_partition();
    int MAXN = subtask_no ? 100000 : 300;
    if (type == SMALL_N) MAXN = 15;
    int n = maximal ? MAXN : random_int(1, MAXN);
    int nz = (type == NONZERO);
    P = random_int(15, 199); //my birthday :D
    for (int i = 1; i <= n; ++i) inq[i] = 0;
    while (!positions.empty()) positions.pop();
    cout << n << '\n';
    for (int i = 1; i <= n; ++i) {
        solution::a[i] = 0;
        int ngroup = random_int(0, cur);
        int a = get_value(nz, 1 << ngroup);
        solution::assign(i, a);
        cout << a;
        if (i < n) cout << ' ';
    }
    cout << '\n';
    int q = maximal ? MAXN : random_int(1, MAXN);
    cout << q << '\n';
    int last = 0;
    for (int i = 1; i <= q; ++i) {
        int typ = (random_int(0, 4) == 0); //roughly 1/4 of the queries will be '?'
        if (last || i == q - 1) typ = 0;
        if (i == q) typ = 1;
        last = typ;
        if (typ == 0) {
            int x;
            int allowed_groups;
            int rd = random_int(0, positions.size() + 10);
            if (rd < positions.size()) {
                x = positions.top().second;
                positions.pop();
                inq[x] = 0;
                allowed_groups = 1 << random_int(0, cur);
            }
            else {
                x = random_int(1, n + 1);
                if (!inq[x]) inq[x] = 1, positions.push(make_pair(random_int(), x));
                allowed_groups = random_int(0, 1 << cur);
            }
            solution::clear(x);
            int y = get_value(nz, allowed_groups);
            if (!nz && i == q - 1 && !zeroed) zeroed = 1, y = 0;
            solution::assign(x, y);
            cout << '!' << ' ' << x << ' ' << y;
        }
        else cout << '?';
        cout << '\n';
    }
}
}

int ntest = 50;
int subtask_1 = 15;

int main(void) {
    srand(time(NULL));
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    int type = 0;
    for (int test = 0; test < ntest; ++test) {
        int subtask_no = (test >= subtask_1), id = test - subtask_no * subtask_1;
        if (test == 3)  ++type;   //SMALL_N, subtask 1: 3 tests
        if (test == 6)  ++type;   //NONZERO, subtask 1: 3 tests
        if (test == 15) --type;   //DEFAULT, subtask 1: 9 tests
        if (test == 20) ++type;   //NONZERO, subtask 2: 5 tests
        if (test == 50) ++type;   //DEFAULT, subtask 2: 30 tests
        int maximal = 0;
        if (ntest - test <= 5 || (test < subtask_1 && subtask_1 - test <= 3)) maximal = 1; //maximal: 3 tests for subtask 1, 5 for subtask 2
        string name = "subtask" + to_string(subtask_no + 1, 1) + '_' + to_string(id, 2);
        cerr << name << ' ' << type << endl;
        string inp = name + ".inp";
        freopen(inp.c_str(), "w", stdout);
        test_generator::run(subtask_no, type, maximal);
    }
}
