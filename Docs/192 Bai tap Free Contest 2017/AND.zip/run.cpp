#include <bits/stdc++.h>

using namespace std;

namespace solution {
int n, q;
int a[100005];
int g[31][31];
int cnt[31];
int zeroes;
bool visited[31];

int myvector[31], s;
void add(int num, int sign) {
    if (num == 0) {
        zeroes += sign;
        return;
    }
    for (int i = 0; i < 30; ++i) if (num >> i & 1) myvector[s++] = i;
    for (int i = 0; i < s; ++i) cnt[myvector[i]] += sign;
    for (int i = 0; i < s; ++i) for (int j = 0; j < s; ++j) g[myvector[i]][myvector[j]] += sign;
    s = 0;
}

void run(void) {
    for (int i = 0; i < 30; ++i) cnt[i] = 0;
    for (int i = 0; i < 30; ++i) for (int j = 0; j < 30; ++j) g[i][j] = 0;
    s = zeroes = 0;

    cin >> n;
    for (int i = 1; i <= n; ++i) {
        int x;
        cin >> x;
        add(x, 1);
        a[i] = x;
    }
    cin >> q;
    while (q--) {
        char type; cin >> type;
        if (type == '?') {
            for (int i = 0; i < 30; ++i) visited[i] = 0;
            int ans = zeroes;
            for (int i = 0; i < 30; ++i) if (cnt[i] > 0 && !visited[i]) {
                ++ans;
                visited[i] = 1;
                myvector[s++] = i;
                while (s) {
                    int u = myvector[--s];
                    for (int v = 0; v < 30; ++v) if (g[u][v] && !visited[v]) {
                        visited[v] = 1;
                        myvector[s++] = v;
                    }
                }
            }
            cout << ans << '\n';
        }
        else {
            int x, y; cin >> x >> y;
            add(a[x], -1);
            a[x] = y;
            add(a[x], 1);
        }
    }
}
}

string to_string(int x, int trunc) {
    string ret;
    for (int i = 0; i < trunc; ++i) {
        ret += char(x % 10 + '0');
        x /= 10;
    }
    reverse(ret.begin(), ret.end());
    return ret;
}

int ntest = 50;
int subtask_1 = 15;

int main(void) {
    srand(time(NULL));
    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);
    for (int test = 0; test < ntest; ++test) {
        int subtask_no = (test >= subtask_1), id = test - subtask_no * subtask_1;
        string name = "subtask" + to_string(subtask_no + 1, 1) + '_' + to_string(id, 2);
        cerr << name << endl;
        string inp = name + ".inp", out = name + ".out";
        freopen(inp.c_str(), "r", stdin);
        freopen(out.c_str(), "w", stdout);
        solution::run();
    }
}
