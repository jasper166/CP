// To run: ./checker <in> <out> <ans> <report>

#include "bits/stdc++.h"
#include "testlib_themis.h"
using namespace std;

vector< vector<int> > g;

void readInput() {
    int n = inf.readInt();
    int m = inf.readInt();

    g.resize(n);

    for (int i = 0; i < m; i++) {
        int u = inf.readInt() - 1;
        int v = inf.readInt() - 1;

        g[u].push_back(v);
        g[v].push_back(u);
    }
}

void doubleGraph() {
    int n = g.size();

    // Add vertex n + i
    for (int i = 0; i < n; i++) {
        g.push_back(vector<int> (0));
    }

    // For all edges(u, v), add edge (u+n, v+n)
    for (int u = 0; u < n; u++) {
        for (int i = 0; i < (int)g[u].size(); ++i) {
        	int v = g[u][i];
            g[u+n].push_back(v+n);
        }
    }

    // Add edge (u, u+n)
    for (int u = 0; u < n; u++) {
        g[u].push_back(u+n);
        g[u+n].push_back(u);
    }
}

void removeVertex(int removeId) {
    int n = g.size();

    // First, we remove u from all adjacency list.
    for (int u = 0; u < n; u++) {
        g[u].erase(std::remove(g[u].begin(), g[u].end(), removeId), g[u].end());
    }

    // Then we remove g[u]
    g.erase(g.begin() + removeId);

    // Finally, we renumber the vertices
    for (int u = 0; u < n - 1; u++) {
        for (int i = 0; i < (int) g[u].size(); i++) {
            if (g[u][i] > removeId) {
                --g[u][i];
            }
        }
    }
}

const int MN = 1e4;
void readOutput() {
    int q = ouf.readInt(0, MN, "number of operations");

    while (q--) {
        int command = ouf.readInt(1, 2, "operation type");
        
        if (command == 2) doubleGraph();
        else {
            int n = g.size();
            int u = ouf.readInt(1, n, "vertex to remove") - 1;
            if (g[u].size() % 2 == 0) {
                quitf(_wa, "Vertex has even degree\n");
            }
            removeVertex(u);
        }
        
        if (g.size() > MN) {
            quitf(_wa, "Number of vertices > 10^4\n");
        }
    }

    for (int i = 0; i < (int) g.size(); i++)
        if (!g[i].empty()) {
            quitf(_wa, "Final graph has edge\n");
        }
}

int main(int argc, char* argv[]) {
#ifdef THEMIS
	registerTestlibThemis("TRANS.INP", "TRANS.OUT");
#else
	registerTestlibCmd(argc, argv);
#endif // THEMIS

    readInput();

    readOutput();
    quitf(_ok, "Correct\n");

    inf.readEof();
}
