// LMAO

#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> II;

const int MAXN = 100 + 10;

string intToStr(int n) {
    stringstream is; is << n;
    return is.str();
}

struct subtask1 {
    void Run(int TC) {
        int p[MAXN];
        int n = rand() % 2 + 99;
        int m = n - 1;
        for (int i = 1; i <= n; ++i) p[i] = i;
        random_shuffle(p + 1, p + 1 + n);

        string dir = "TRANS/sub1_" + intToStr(TC);
        system(("mkdir " + dir).c_str());

        fstream f(dir + "/TRANS.INP", ios::out);
        f << n << " " << m << "\n";
        for (int i = 2; i <= n; ++i) {
            int u = p[rand() % (i - 1) + 1];
            int v = p[i];
            f << u << " " << v << "\n";
        }
        f.close();

        system(("./sol < " + (dir + "/TRANS.INP") + " > " + (dir + "/TRANS.OUT")).c_str());
    }
} subtask1;

struct subtask2 {
    void Run(int TC) {
        int p[MAXN];
        int n = rand() % 2 + 99;
        for (int i = 1; i <= n; ++i) p[i] = i;

        vector<II> edges;
        int len = rand() % (n / 2 - 20 + 1) + 20;
        len -= len % 2;
        random_shuffle(p + len + 1, p + 1 + n);
        for (int i = 1; i <= len; ++i) {
            int u = p[i];
            int v = p[i % len + 1];
            edges.push_back(II(u, v));
        }
        for (int i = len + 1; i <= n; ++i) {
            int type = rand() % 2;
            int j = rand() % (n - i + 1) + i;
            if (i == j || i == j - 1) type = 0;
            for (int k = i; k < j; ++k) {
                int u = p[k];
                int v = p[k + 1];
                edges.push_back(II(u, v));
            }
            if (type == 1) edges.push_back(II(p[i], p[j]));
            i = j;
        }

        string dir = "TRANS/sub2_" + intToStr(TC);
        system(("mkdir " + dir).c_str());

        fstream f(dir + "/TRANS.INP", ios::out);
        f << n << " " << (int) edges.size() << "\n";
        for (int i = 0; i < (int) edges.size(); ++i) {
            int u = edges[i].first;
            int v = edges[i].second;
            f << u << " " << v << "\n";
        }
        f.close();

        system(("./sol < " + (dir + "/TRANS.INP") + " > " + (dir + "/TRANS.OUT")).c_str());
    }
} subtask2;

struct subtask3 {
    void Run(int TC) {
        int p[MAXN];
        int n = rand() % 2 + 99;
        int m = rand() % 101 + 900;
        for (int i = 1; i <= n; ++i) p[i] = i;

        vector<II> edges;
        set<II> S;
        int len = rand() % (20 - 10 + 1) + 10;
        len -= len % 2;
        random_shuffle(p + len + 1, p + 1 + n);
        for (int i = 1; i <= len; ++i) {
            int u = p[i];
            int v = p[i % len + 1];
            edges.push_back(II(u, v));
            S.insert(II(u, v));
        }

        while ((int) edges.size() < m) {
            int u = p[rand() % (n - len) + len + 1];
            int v = p[rand() % (n - len) + len + 1];
            if (u == v || S.count(II(u, v)) || S.count(II(v, u))) continue;
            S.insert(II(u, v));
            edges.push_back(II(u, v));
        }

        string dir = "TRANS/sub3_" + intToStr(TC);
        system(("mkdir " + dir).c_str());

        fstream f(dir + "/TRANS.INP", ios::out);
        f << n << " " << (int) edges.size() << "\n";
        for (int i = 0; i < (int) edges.size(); ++i) {
            int u = edges[i].first;
            int v = edges[i].second;
            f << u << " " << v << "\n";
        }
        f.close();

        system(("./sol < " + (dir + "/TRANS.INP") + " > " + (dir + "/TRANS.OUT")).c_str());
    }
} subtask3;

int main() {
    srand(7777);
    system("g++ TRANS.cpp -o sol");
    for (int i = 1; i <= 20; ++i) subtask1.Run(i);
    for (int i = 1; i <= 35; ++i) subtask2.Run(i);
    for (int i = 1; i <= 45; ++i) subtask3.Run(i);
    return 0;
}