#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef pair<int, int> II;

const int MAXN = 200 + 10;
int n, m, a[MAXN][MAXN];
vector<int> ans;

int b[MAXN][MAXN];
int origin[MAXN];
int nOrigin[MAXN];

void ReNumber(int T) {
	for (int u = 1; u <= n; ++u) {
		if (u == T) {
			continue;
		}
		for (int v = 1; v <= n; ++v) {
			if (v == T) {
				continue;
			}
			int x = (u < T) ? u : (u - 1);
			int y = (v < T) ? v : (v - 1);
			b[x][y] = a[u][v];
		}
	}
	for (int i = 1; i <= n - 1; ++i) {
		a[i][0] = 0;
		for (int j = 1; j <= n - 1; ++j) {
			a[i][j] = b[i][j];
			a[i][0] ^= a[i][j];
		}
	}
}

void Remove(int u) {
	ans.push_back(-u);
	for (int v = 1; v <= n; ++v) {
		a[u][0] ^= a[u][v]; a[u][v] = 0;
		a[v][0] ^= a[v][u]; a[v][u] = 0;
	}
	ReNumber(u);
	n -= 1;
}

void addEdge(int u, int v, int w) {
	a[u][v] = w; a[u][0] ^= w;
	a[v][u] = w; a[v][0] ^= w;
}

void Solve() {
	int edgeCnt = 0;
	for (int u = 1; u <= n; ++u) {
		for (int v = 1; v <= n; ++v) {
			edgeCnt += a[u][v];
		}
	}
	if (edgeCnt == 0) {
		return;
	}
    vector<int> p;
    for (int i = 1; i <= n; ++i) p.push_back(i);
    random_shuffle(p.begin(), p.end());
	for (int i = 1; i <= n; ++i) {
        int u = p[i - 1];
        if (a[u][0] == 0) {
            continue;
        }
        Remove(u);
        Solve();
        return;
    }
    
	// Double the graph
	ans.push_back(2);

	for (int u = 1; u <= n; ++u) {
		int u1 = u + n;
		a[u1][0] = 0;
		for (int v = 1; v <= n; ++v) {
			addEdge(u1, v, 0);
			addEdge(u1, v + n, a[u][v]);
		}
		addEdge(u, u1, 1);
	}
    n *= 2;
	Solve();
}

int main() {
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= m; ++i) {
		int u, v; scanf("%d%d", &u, &v);
        addEdge(u, v, 1);            
	}
	Solve();

	printf("%d\n", (int) ans.size());
	for (int i = 0; i < (int) ans.size(); ++i) {
		if (ans[i] == 2) puts("2");
		else printf("%d %d\n", 1, -ans[i]);
	}
	return 0;
}