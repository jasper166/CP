#include "race.h"

int best_path(int N, int K, int H[][2], int L[])
{
  return N;
}

