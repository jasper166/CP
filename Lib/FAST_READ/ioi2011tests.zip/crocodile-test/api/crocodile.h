int travel_plan(int N, int M, int R[][2], int L[], int K, int P[]);
