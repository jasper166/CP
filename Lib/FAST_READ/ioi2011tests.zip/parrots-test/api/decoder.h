void decode(int N, int L, int X[]);
