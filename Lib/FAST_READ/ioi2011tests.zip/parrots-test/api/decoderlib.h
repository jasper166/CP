void output(int b);
